
package sample.test.sample;

import org.junit.Test;

import static org.junit.Assert.*;

public class InvoiceOrderTest {

    @Test
    public void setWindow() {
    }

    @Test
    public void initOrder() {
    }
}
