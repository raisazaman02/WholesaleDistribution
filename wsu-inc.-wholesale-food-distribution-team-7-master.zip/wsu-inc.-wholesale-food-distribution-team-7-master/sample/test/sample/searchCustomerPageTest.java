
package sample.test.sample;

import static org.junit.Assert.*;

public class searchCustomerPageTest {

}

