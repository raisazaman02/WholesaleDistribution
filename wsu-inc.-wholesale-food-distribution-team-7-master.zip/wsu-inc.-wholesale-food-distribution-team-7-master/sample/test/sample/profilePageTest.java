
package sample.test.sample;

import org.junit.Test;

import static org.junit.Assert.*;

public class profilePageTest {

    @Test
    public void setWindow() {
    }
}

