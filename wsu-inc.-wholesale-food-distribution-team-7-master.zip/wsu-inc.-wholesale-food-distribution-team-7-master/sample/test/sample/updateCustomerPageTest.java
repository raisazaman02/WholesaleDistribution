
package sample.test.sample;

import org.junit.Test;

import static org.junit.Assert.*;

public class updateCustomerPageTest {

    @Test
    public void setWindow() {
    }

    @Test
    public void initUsers() {
    }
}
