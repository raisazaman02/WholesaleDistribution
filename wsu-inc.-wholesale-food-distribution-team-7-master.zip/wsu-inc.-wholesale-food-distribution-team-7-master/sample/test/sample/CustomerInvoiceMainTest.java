
package sample.test.sample;

import org.junit.Test;

import static org.junit.Assert.*;

public class CustomerInvoiceMainTest {

    @Test
    public void alertTwoOrderAvailable() {
    }

    @Test
    public void setWindow() {
    }
}
